package cs3500.animator.model.animationobjects;

/**
 * An enumeration to represent all of the AnimationObjectTypes in our program.
 */
public enum AnimationObjectTypes {
  RECTANGLE,
  //TEXT,
  //TRIANGLE,
  ELLIPSE
}
